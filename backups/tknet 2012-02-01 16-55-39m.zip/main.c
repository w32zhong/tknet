#include "headers.h"

#define SLEEP( _ms ) usleep( _ms * 1000)
void tkNetInit();
void tkNetUninit();
BOOL g_MainLoopFlag = 1;

int main()
{
	struct ProcessingList ProcList;

	tkNetInit();
	ProcessingListCons( &ProcList );

	MutexInit(&g_BkgdMutex);
	tkBeginThread( &BackGround , &ProcList );

	while( g_MainLoopFlag )
	{
		MutexLock(&g_BkgdMutex);
		DoProcessing( &ProcList );
		MutexUnlock(&g_BkgdMutex);

		SLEEP(100);
	}

	MutexDelete(&g_BkgdMutex);
	tkNetUninit();
	return 0;
}

void tkNetInit()
{
	tkInitRandom();
	tkLogInit();
	SockInit();
}

void tkNetUninit()
{
	SockDestory();
	tkLogClose();
	printf("unfree memory:%d \n",g_allocs);
}
