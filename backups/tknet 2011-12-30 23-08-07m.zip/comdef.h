#ifndef NULL
#define NULL 0
#endif

#ifndef BOOL
#define BOOL int
#endif

typedef unsigned int uint;
typedef unsigned short ushort;

#define DEF_STRUCT_CONSTRUCTOR( _type_name , _assignments ) \
        void \
        _type_name ## Cons( struct _type_name * out_cons) \
        { \
                _assignments \
        }

#define DECLARATION_STRUCT_CONSTRUCTOR( _type_name ) \
            void _type_name ## Cons( struct _type_name * );

#define DEF_AND_CAST( _to_var , _type_tag_casting_to , _from_var ) \
	_type_tag_casting_to * _to_var = ( _type_tag_casting_to *) _from_var

#define MEMBER_OFFSET( _type_tag , _member ) (int)(&( (( _type_tag *)0)-> _member ))

#define GET_STRUCT_ADDR( _member_addr , _type_tag , _member_name ) \
	( _type_tag *)((int)( _member_addr ) - MEMBER_OFFSET( _type_tag , _member_name ) )

#define TK_EXCEPTION( _describe ) \
	_descr_exception_( __FILE__ ": " #_describe " exception at line " \
	, __LINE__ )

static __inline void
_descr_exception_(const char* pa_presay ,uint pa_l)
{
	char LineBuff[16];
	tkLog(0,pa_presay);
	tkFormatStr(LineBuff,"%d",pa_l);
	tkLog(0,LineBuff);
	tkLog(0,".\n");
}

#define VCK( _cdt , _statments ) \
	if( _cdt ) \
	{ \
		TK_EXCEPTION( _cdt ); \
		_statments ; \
	}do{}while(0)


