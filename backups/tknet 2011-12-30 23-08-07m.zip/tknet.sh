#!/bin/bash
if [ ! $1 ]
then
	scons && echo ----run---- && ./run
	ctags -R
elif [ $1 == 'g++' ]
then
	codefiles=`ls | grep -v 'demo' | grep '\.c$'`
	g++ $codefiles && echo ----run---- && ./a.out
	ctags -R
elif [ $1 == 'clean' ]
then
	scons -c
	rm a.out
	rm tags
	rm *.log
elif [ $1 == 'bkup' ]
then
	date --rfc-3339=seconds | grep -o '.*+' > name.tmp
	sed -i -e 's/^/tknet /' name.tmp
	sed -i -e 's/:/-/g' name.tmp
	zipfilename=`sed -e 's/.$/m/' name.tmp `
	rm name.tmp
	zip "$zipfilename" ./*
	mkdir -p backups
	cp *.zip backups/
	cp *.zip /media/KINGSTON/tknet_backups/
	rm *.zip
elif [ $1 == 'win' ]
then
	mkdir -p Dos\ format
	codefiles=`ls | grep '\.[ch]$'`
	for file in $codefiles
	do
		sed -e 's/$/\r/' $file >> Dos\ format/$file
	done
	rm -r -f ../Shared\ Folder/Dos\ format
	mv Dos\ format ../Shared\ Folder/
else
	echo 'input unexpected.'
fi
