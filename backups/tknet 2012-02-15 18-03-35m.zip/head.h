#ifdef _MSC_VER
#pragma warning(disable:4996)
#endif

struct PeerData;
