void 
Base64Encode(char *src, int src_len, char *dst);
// dst and src must be different buffer.
