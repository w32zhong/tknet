#include "headers.h"
#include <stdio.h>

int
main()
{
	tkLogInit();
	VCK( 3==3 , ; );
	return 0;
}
