#include "headers.h"

struct NetAddr
{
	uint    IPv4;
	ushort  port;
};

#define NAT_T_UNKNOWN         0x00
#define NAT_T_FULL_CONE       0x01
#define NAT_T_RESTRICTED      0x02
#define NAT_T_PORT_RESTRICTED 0x03
#define NAT_T_SYMMETRIC       0x04

struct PeerData
{
	struct NetAddr   addr;
	uchar            NATType;
	struct Treap     tpnd;
};

DEF_STRUCT_CONSTRUCTOR( PeerData ,
		out_cons->NATType = NAT_T_UNKNOWN;
		out_cons->IProcessHead = GetIterator(NULL);
		out_cons->IProcessNow  = GetIterator(NULL);
		TreapCons(&out_cons->tpnd);
		)


BOOL NetAddrCompare(struct BinTreeNode* pa_pBinNode0 ,
		struct BinTreeNode* pa_pBinNode1 , void* pa_else)
{
	struct PeerData* p0 = GET_STRUCT_ADDR( pa_pBinNode0 , struct PeerData , tpnd.btnd );
	struct PeerData* p1 = GET_STRUCT_ADDR( pa_pBinNode1 , struct PeerData , tpnd.btnd );

	if( p0->addr.port != p1->addr.port )
	{
		return p0->addr.port > p1->addr.port;
	}
	else
	{
		return p0->addr.IPv4 > p1->addr.IPv4;
	}
}

BOOL ifNetAddrEqual(struct BinTreeNode* pa_pBinNode0 ,
		struct BinTreeNode* pa_pBinNode1 , void* pa_else)
{
	struct PeerData* p0 = GET_STRUCT_ADDR( pa_pBinNode0 , struct PeerData , tpnd.btnd );
	struct PeerData* p1 = GET_STRUCT_ADDR( pa_pBinNode1 , struct PeerData , tpnd.btnd );

	if( p0->addr.IPv4 == p1->addr.IPv4 && p0->addr.port == p1->addr.port)
	{
		return 1;
	}
	else
	{
		return 0;
	}

}

struct Iterator IRecvingSockQueue;
struct PeerData PeerDateRoot;

struct PeerData* 
MapPeerData(struct NetAddr* pa_addr)
{
	struct BinTreeNode *pFind;
	struct PeerData    *pPeerData,ToFind;

	ToFind.addr = *pa_addr;
	pFind = BinTreeFind(&PeerDateRoot.tpnd.btnd,&ToFind.tpnd.btnd,&NetAddrCompare,&ifNetAddrEqual,NULL);

	if(pFind == NULL)
	{
		pPeerData = tkmalloc(struct PeerData);
		PeerDataCons(pPeerData);
		pPeerData->addr = ToFind.addr;
		TreapInsert(&pPeerData->tpnd,&PeerDateRoot.tpnd,&NetAddrCompare , NULL);
	}
	else
	{
		pPeerData = GET_STRUCT_ADDR( pFind , struct PeerData , tpnd.btnd );
	}
		
	return pPeerData;
}

BOOL LIST_ITERATION_CALLBACK_FUNCTION(RecvingSockReadCallbk)
{
	struct RecvingSock* pRcso = GET_STRUCT_ADDR_FROM_IT( pa_pINow , struct RecvingSock , ln);
	struct NetAddr addr;
	struct PeerData *pPeerData; 

	if( SockRead(&pRcso->sock) )
	{
		addr.IPv4 = ntohl( pRcso->sock.AddrTa.sin_addr.s_addr );
		addr.port = ntohl( pRcso->sock.AddrTa.sin_port );
		pPeerData = MapPeerData(&addr);
	}
}

int main()
{
	struct RecvingSock reso;

	TreapCons(&PeerDateRoot.tpnd);
	PeerDateRoot.tpnd.RanPriority = 0;

	SockInit();
	tkLogInit();

	SockOpen(&reso.sock,TCP,0);
	SockLocateTa(&reso.sock,GetIPVal("123.125.50.23"),995);
	SockSSLConnect(&reso.sock);
	SockSetNonblock(&reso.sock);
	ListNodeCons(&reso.ln);
	AddOneToListTail(&IRecvingSockQueue,&reso.ln);

	return 0;

	while(1)
	{
		ForEach( &IRecvingSockQueue , &RecvingSockReadCallbk , NULL );
	}
	//SockRead(&reso.sock);
	while(!SockRead(&reso.sock));
	printf("%s \n",reso.sock.RecvBuff);
	SockWrite(&reso.sock,StrBys("USER clock126\r\n") );
	while(!SockRead(&reso.sock));
	printf("%s \n",reso.sock.RecvBuff);

	SockDestory();
	return 0;
}

/*
int SockTalk( struct Sock* pa_sock , TalkSteps pa_StepCallbk , 
		uint pa_retrys ,uint pa_WaitClocks )
{
	clock_t dt = 0,t0 = clock();
	int step = 0 , retrys = (pa_retrys==0)?1:pa_retrys;

	while(1)
	{
		write

		while( dt < pa_WaitClocks )
		{
			if( SockRead( pa_sock ) )
			{

			}

			dt = clock() - t0;
			if( dt < 0 )
			{
				t0 = clock();
			}
		}
		end  = (clock() - start)/CLOCKS_PER_SEC;
		
		retrys --;
	}
}*/
