extern unsigned int g_allocs;

void*
_tkmalloc( unsigned int );

void
_tkfree( void* );

#define tkmalloc( _type_tage ) \
    ( _type_tage *)_tkmalloc( sizeof ( _type_tage ) )

#define tkfree( _mem ) \
    _tkfree( _mem ); \
    _mem = NULL

void 
tkInitRandom();

unsigned int 
tkGetRandom();

#define LOG_FILES 2

int
tkLogInit();

void
tkLog( unsigned int , const char* );

void
tkLogClose();

void 
tkFormatStr(char* , const char* , ... );
