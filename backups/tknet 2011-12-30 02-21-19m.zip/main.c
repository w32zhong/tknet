#include "headers.h"
#include <stdio.h>

#if defined( __GNUC__ ) && defined( __linux__ )

#include <sys/socket.h>
#include <netinet/in.h>

typedef int SOCKVAL;
#define SOCK_ERROR_CDT < 0
#define WSAINIT
#define WSACLEAN

#elif defined _MSC_VER

#undef BOOL
#include <winsock2.h>
#pragma comment(lib,"ws2_32.lib")

typedef SOCKET SOCKVAL;
#define SOCK_ERROR_CDT == SOCKET_ERROR
#define WSACLEAN WSACleanup()
#define WSAINIT  WSADATA wsa ; \
	WSAStartup(MAKEWORD(2,2), &wsa)

#endif

#define SOCK_RECV_BUFF_LEN 2048

#define UDP SOCK_DGRAM
#define TCP SOCK_STREAM

void SockInit()
{
	WSAINIT;
}

/*
#include <unistd.h>
#include <fcntl.h>
.
.
.
sockfd = socket(PF_INET, SOCK_STREAM, 0);
fcntl(sockfd, F_SETFL, O_NONBLOCK);
*/

#include <string.h>

struct Bys
{
	const char* pBytes;
	uint  len;
};

struct Bys StrBys(const char* in_str)
{
	struct Bys res;
	res.pBytes = in_str;
	res.len = strlen(in_str);

	return res;
}

struct Sock
{
	struct sockaddr_in AddrTa,AddrMe,AddrRecvfrom;
	SOCKVAL	socket;
	int 	proto;
	uint	RecvLen;
	char	RecvBuff[SOCK_RECV_BUFF_LEN];
};

void SockOpen(struct Sock* out_sock , int pa_proto , ushort pa_port)
{
	VCK( (out_sock->socket = socket(AF_INET, pa_proto ,0))
			SOCK_ERROR_CDT , WSACLEAN; return );

	if( pa_proto == UDP )
	{
		out_sock->AddrMe.sin_family = AF_INET;
		out_sock->AddrMe.sin_port = htons(pa_port);
		out_sock->AddrMe.sin_addr.s_addr = htonl(INADDR_ANY);
		//since INADDR_ANY is defined in host byte order ,
		//it need to be converted to network byte order.

		VCK( bind( out_sock->socket ,(struct sockaddr*)&out_sock->AddrMe , 
					sizeof(struct sockaddr_in)) SOCK_ERROR_CDT ,
				 	return );
	}

	out_sock->proto = pa_proto;
}

void
GetIPTextAndPort(struct sockaddr_in* in_addr , ushort* out_pPort , char* pa_pBuff )
{
	char* pStatBuff;
	
	*out_pPort = ntohs(in_addr->sin_port);
	
	pStatBuff = (char*)inet_ntoa(in_addr->sin_addr);
	//for implementation to support IPv6 ,
	//inet_ntoa(), inet_aton(), inet_addr() are deprecated.

	strcpy( pa_pBuff , pStatBuff );
}

__inline
uint GetIPVal(const char* in_text)
{
	//for implementation to support IPv6 ,
	//inet_ntoa(), inet_aton(), inet_addr() are deprecated.

	return inet_addr(in_text);
}

void SockLocateTa( struct Sock* pa_sock , uint in_IPVal , ushort pa_port )
{
	pa_sock->AddrTa.sin_family = AF_INET;
	pa_sock->AddrTa.sin_port = htons(pa_port);
	pa_sock->AddrTa.sin_addr.s_addr = in_IPVal;

	if( pa_sock->proto == TCP )
	{
		VCK( connect( pa_sock->socket , (struct sockaddr*)&pa_sock->AddrTa ,
					sizeof( struct sockaddr_in)) SOCK_ERROR_CDT ,
				return );
	}
}

void SockWrite( struct Sock* pa_sock , struct Bys pa_bys )
{
	if( pa_sock->proto == TCP )
	{
		VCK( send(pa_sock->socket,pa_bys.pBytes,pa_bys.len,0) SOCK_ERROR_CDT,
				return );
	}
	else if( pa_sock->proto == UDP )
	{
		VCK( sendto(pa_sock->socket,pa_bys.pBytes,pa_bys.len,0,
					(struct sockaddr*)&pa_sock->AddrTa,
					sizeof( struct sockaddr_in ) ) SOCK_ERROR_CDT,
					return );
	}
}

void SockRead( struct Sock* pa_sock )
{
	uint res;
	uint alen;

	if( pa_sock->proto == TCP )
	{
		res = recv(pa_sock->socket , pa_sock->RecvBuff , SOCK_RECV_BUFF_LEN , 0);
	}
	else if( pa_sock->proto == UDP )
	{
		alen = sizeof( struct sockaddr_in );
		res = recvfrom( pa_sock->socket , pa_sock->RecvBuff ,
				SOCK_RECV_BUFF_LEN , 0 ,
				(struct sockaddr*)&pa_sock->AddrRecvfrom , &alen);
	}
		
	VCK( res < 0 , res = 0; );
	pa_sock->RecvBuff[res] = '\0';
	pa_sock->RecvLen = res;
}

#if 1

int
main()
{
	struct Sock client;
	ushort port;
	char buff[32];
	
	SockInit();
	tkLogInit();

	SockOpen( &client , UDP , 8812 );
	
	GetIPTextAndPort(&client.AddrMe,&port,buff);
	printf("my addr: %s/%d \n",buff,port);

	SockLocateTa( &client , GetIPVal("127.0.0.1") , 8821 );

	GetIPTextAndPort(&client.AddrTa,&port,buff);
	printf("ta addr: %s/%d \n",buff,port);

	SockWrite( &client , StrBys("Hello!") );

	return 0;
}

#else

int
main()
{
	struct Sock host;
	ushort port;
	char buff[32];
	
	SockInit();
	tkLogInit();

	SockOpen( &host , UDP , 8821 );

	SockRead( &host );

	GetIPTextAndPort(&host.AddrRecvfrom,&port,buff);

	printf("read:%s ,from %s/%d \n",host.RecvBuff,buff,port);

	return 0;
}

#endif
